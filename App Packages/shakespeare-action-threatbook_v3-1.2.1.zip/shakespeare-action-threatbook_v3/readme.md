
# APP文档帮助文档

## 一、APP介绍


描述：产品介绍  


| 内容 | 详细描述 |
| ---- | ------ |
| app版本      | 2.0 |
| 发布时间     | 2023-10-05|18:55:38 |
| 应用连接方式  |  |
| 支持版本     |  |
| 作者        |  |

## 二、app使用注意事项

1）APP已测试通过型号&版本

| 型号   | 软件版本  |
| ----- | ------- |
| 无 |  |

2）作者提示
> 
> 

3）更新说明
> 
>


## 三、动作说明

### 1）scanFile
动作描述：扫描文件
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| file_path |  OUTSIDE_FILE  |  | True |  |  要扫描的文件  |
| sandbox_type |  string  |  | False |  |  沙箱类型  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data.response_code |  integer  |  |  可为以下值：1：上传成功，正在排队-1：出错，具体查看verbose_msg的返回  |
| action_result.data.verbose_msg |  string  |  |  response_code相应的详细信息  |
| action_result.data.data.permalink |  string  |  |  查看扫描报告的URL  |
| action_result.data.data.sha256 |  string  |  |  文件的sha256值  |

### 2）scanUrl
动作描述：扫描url
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| url |  string  |  | True |  |  要扫描的url  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data.response_code |  integer  |  |  可为以下值：1：上传成功，正在排队-1：出错  |
| action_result.data.verbose_msg |  string  |  |  response_code相应的详细信息  |
| action_result.data.data.permalink |  string  |  |  查看扫描报告的URL  |
| action_result.data.data.time |  string  |  |  扫描时间  |

### 3）scanFileForPlaybook
动作描述：扫描文件
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| file_path |  string  |  | True |  |  要扫描的文件  |
| sandbox_type |  string  |  | False |  |  沙箱类型  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data.response_code |  integer  |  |  可为以下值：1：上传成功，正在排队-1：出错，具体查看verbose_msg的返回  |
| action_result.data.verbose_msg |  string  |  |  response_code相应的详细信息  |
| action_result.data.data.permalink |  string  |  |  查看扫描报告的URL  |
| action_result.data.data.sha256 |  string  |  |  文件的sha256值  |

### 4）getScanFileReport
动作描述：获取文件扫描报告
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| sha256 |  string  |  | True |  |  可为以下值：sha256  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data.response_code |  integer  |  |  可为以下值：1：上传成功，正在排队-1：出错，具体查看verbose_msg的返回  |
| action_result.data.verbose_msg |  string  |  |  response_code相应的详细信息  |
| action_result.data.data.threat_score |  string  |  |  威胁评分  |
| action_result.data.data.file_type |  string  |  |  文件类型  |
| action_result.data.threat_level |  string  |  |  威胁等级  |

### 5）getScanUrlReport
动作描述：获取url扫描报告
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| url |  string  |  | True |  |  url  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data.response_code |  integer  |  |  可为以下值：1：上传成功，正在排队-1：出错，具体查看verbose_msg的返回  |
| action_result.data.verbose_msg |  string  |  |  response_code相应的详细信息  |
| action_result.data.threat_level |  string  |  |  威胁等级  |

### 6）domainQuery
动作描述：域名分析
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| domain |  string  |  | True |  |  要查询的域名  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data.cur_whois.registrar_name |  string  |  |  域名服务商  |
| action_result.data.cur_whois.registrant_email |  string  |  |  注册邮箱  |
| action_result.data.cur_whois.registrant_phone |  string  |  |  注册电话  |
| action_result.data.cur_whois.cdate |  string  |  |  注册时间  |
| action_result.data.cur_whois.udate |  string  |  |  更新时间  |
| action_result.data.cur_whois.edate |  string  |  |  过期时间  |
| action_result.data.cur_ips.*.ip |  string  |  |  当前解析ip  |
| action_result.data.cur_ips.*.carrier |  string  |  |  运营商  |
| action_result.data.cur_ips.*.location.country |  string  |  |  国家  |
| action_result.data.cur_ips.*.location.province |  string  |  |  省  |
| action_result.data.cur_ips.*.location.city |  string  |  |  城市  |
| action_result.data.cur_ips |  string  |  |  域名的解析的ip信息  |
| action_result.data.judgments |  string  |  |  威胁类型  |
| action_result.data.intelligences |  string  |  |  威胁情报  |
| action_result.data.samples |  string  |  |  相关样本  |

### 7）ipQuery
动作描述：IP分析
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| ip |  string  |  | True |  |  要查询的IP(不支持内网ip)  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data.basic.carrier |  string  |  |  运营商  |
| action_result.data.basic.location.country |  string  |  |  国家  |
| action_result.data.basic.location.province |  string  |  |  省  |
| action_result.data.basic.location.city |  string  |  |  城市  |
| action_result.data.judgments |  string  |  |  威胁类型  |
| action_result.data.intelligences |  string  |  |  威胁情报  |
| action_result.data.samples |  string  |  |  相关样本  |
| action_result.data.ports.*.pot |  string  |  |  端口  |
| action_result.data.ports.*.module |  string  |  |  应用协议  |
| action_result.data.ports.*.product |  string  |  |  应用名称  |
| action_result.data.ports.*.version |  string  |  |  应用版本  |

### 8）ipReputation
动作描述：IP信誉查询
对应接口：

**入参说明**

| 参数  | 类型 | 数据样例 | 必须 | 默认值 | 说明   |
| ---- | ----- | ---- | ---- | ---- | ---- |
| ip |  string  |  | True |  |  要查询的IP(不支持内网ip)  |

**出参说明**    

| 参数  | 类型   | 数据样例  | 说明 |
| ---- | ----- | ------- | ---- |  
| action_result.data |  string  |  |  data明细  |
| action_result.data.confidence_level |  string  |  |  confidence_level  |
| action_result.data.severity |  string  |  |  severity  |
| action_result.data.is_malicious |  string  |  |  is_malicious  |
| action_result.data.confidence_level |  string  |  |  confidence_level  |

## 三、资源配置说明

###  1）基本信息配置

| 配置项     | 样例                  | 说明                                           |
| ---------- | --------------------- | ---------------------------------------------- |
| 资源名     |     | 资源名称具备可辨识度，比如设备所在的位置       |
| 描述       |  | 描述尽可能清晰              |
| 产品供应商 |   | 产品生产厂商（可选）        |
| 产品名称   |    | 产品名称 （可选）    |
| 执行引擎   | 任意引擎  | 在多引擎环境下可以指派执行引擎，默认“任意引擎” |
        
### 2）资源配置参数

| 参数 | 类型 | 样例 | 必须 | 默认值 | 说明 |
| ---- | ---- | ---- | ---- | ------ | ---- |
| api_key | password |  |  True  |        |  api_key |
| http_proxy | string |  |  False  |        |  代理地址,示例:127.0.0.1:12333 |
